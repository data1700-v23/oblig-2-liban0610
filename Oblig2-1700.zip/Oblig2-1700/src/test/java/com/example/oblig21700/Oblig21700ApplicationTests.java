package com.example.oblig21700;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Oblig21700ApplicationTests {

    @Test
    void contextLoads() {
    }

}
