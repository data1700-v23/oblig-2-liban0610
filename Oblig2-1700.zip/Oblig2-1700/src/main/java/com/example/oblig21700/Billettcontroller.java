package com.example.oblig21700;

        import org.springframework.web.bind.annotation.GetMapping;
        import org.springframework.web.bind.annotation.PostMapping;
        import org.springframework.web.bind.annotation.RestController;

        import java.util.ArrayList;
        import java.util.List;

@RestController
public class Billettcontroller {

    private final List<Billett> alleBilletter = new ArrayList<>();


    @GetMapping("hentFilmer")
    public List<Filmer> hentFilmer(){
        List<Filmer> listFilmer = new ArrayList<>();
        listFilmer.add(new Filmer("Velg en film"));
        listFilmer.add(new Filmer("Black Panther"));
        listFilmer.add(new Filmer("Fast & Furious 9"));
        listFilmer.add(new Filmer("The Batman"));
        listFilmer.add(new Filmer("Avengers end game"));
        listFilmer.add(new Filmer("Spider man"));
        return listFilmer;
    }

    @GetMapping("/hentAlle")
    public List<Billett> hentAlle(){
        return alleBilletter;
    }

    @PostMapping("/lagre")
    public void lagreBillett(Billett innBillett){
        alleBilletter.add(innBillett);
    }


    @GetMapping("/slettAlle")
    public void slettAlle(){
        alleBilletter.clear();
    }

}


