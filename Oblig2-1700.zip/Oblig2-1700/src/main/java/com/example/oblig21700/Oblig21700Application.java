package com.example.oblig21700;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Oblig21700Application {

    public static void main(String[] args) {
        SpringApplication.run(Oblig21700Application.class, args);
    }

}
