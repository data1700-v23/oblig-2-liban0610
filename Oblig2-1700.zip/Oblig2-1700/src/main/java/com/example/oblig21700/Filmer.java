package com.example.oblig21700;


public class Filmer {
    private String film;

    public Filmer( String film ){

        this.film=film;
    }



    public String getFilm() {
        return film;
    }

    public void setFilm(String film) {
        this.film = film;
    }
}
